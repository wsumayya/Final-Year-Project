from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import PasswordResetForm, AuthenticationForm
from django.contrib import messages
from django.utils.timezone import now
from .forms import RegisterForm, ProfileForm, MealFilterForm
from .models import Profile, Meal, Category, FavouriteMeal, Comment, ViewedMeal, TrackedMeal
from .models import ViewedMeal, FavouriteMeal
import random
from datetime import date, timedelta

# Home Page View
def home(request):
    return render(request, 'home.html')

# User Registration View
def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Hi {username}, your account has been created successfully!')
            return redirect('home')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

# Profile Update View
@login_required
def update_profile(request):
    profile = request.user.profile

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile, user=request.user)
        if form.is_valid():
            form.save(user=request.user)
            return redirect('profile-view')  # or 'dashboard' if you prefer
    else:
        form = ProfileForm(instance=profile, user=request.user)

    return render(request, 'update_profile.html', {'form': form})

# User Login View
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

# User Logout View
def logout_view(request):
    logout(request)
    return redirect('login')

# Password Reset View
def password_reset_view(request):
    if request.method == 'POST':
        form = PasswordResetForm(request.POST)
        if form.is_valid():
            form.save(request=request)
    else:
        form = PasswordResetForm()
    return render(request, 'password-reset.html', {'form': form})

# User Profile View

@login_required
def profile_view(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    return render(request, 'profile-view.html', {
        'user_profile': profile,
        'display_name': request.user.username  # ✅ Always show the username
    })

# Meal Page View
def meal_page(request):
    meals = Meal.objects.all()
    return render(request, 'meal_page.html', {'meals': meals})

# Base View
@login_required
def base_view(request):
    return render(request, 'base.html')

# ✅ Meal Detail View (Fixes Duplicate Entries)
@login_required
def meal_detail(request, meal_id):
    meal = get_object_or_404(Meal, id=meal_id)

    # Handle POST: New review submission
    if request.method == 'POST':
        content = request.POST.get('content')
        if content:
            Comment.objects.create(
                content=content,
                user=request.user,
                meal=meal
            )
            return redirect('meal_detail', meal_id=meal_id)

    # Get existing comments for this meal
    comments = Comment.objects.filter(meal=meal, parent__isnull=True).order_by('-created_at')

    # Track viewed meal
    if request.user.is_authenticated:
        viewed_meal, created = ViewedMeal.objects.get_or_create(user=request.user, meal=meal)
        if not created:
            viewed_meal.viewed_at = now()
            viewed_meal.save()

    return render(request, 'meal-detail.html', {
        'meal': meal,
        'comments': comments
    })





# ✅ Dashboard View (Fixed Recently Viewed Meals)
from collections import Counter
import json

@login_required
def dashboard_view(request):
    profile = request.user.profile
    recently_viewed_meals = ViewedMeal.objects.filter(user=request.user).order_by('-viewed_at')[:4]
    favourite_meals = FavouriteMeal.objects.filter(user=request.user).order_by('-added_at')[:3]

    # 🧠 Goal calorie suggestion
    goal = profile.goal
    base_calories = 2000
    if goal == 'Lose Weight':
        calorie_target = base_calories - 500
    elif goal == 'Gain Muscle':
        calorie_target = base_calories + 300
    else:
        calorie_target = base_calories

    # 💌 Motivation quote
    motivation_quotes = [
        "Every bite counts toward your goal 🥦",
        "You’re doing amazing — keep it up! 💚",
        "Small steps lead to big changes 🌱",
        "Strong body, strong mind 💪",
        "You’ve got this, one meal at a time 🍽️"
    ]
    daily_motivation = random.choice(motivation_quotes)

    # 📊 Category breakdown
    categories = []
    for viewed in ViewedMeal.objects.filter(user=request.user):
        categories += [cat.name for cat in viewed.meal.categories.all()]
    category_counter = Counter(categories)
    category_chart = {
        'labels': list(category_counter.keys()),
        'data': list(category_counter.values())
    }

    # 📈 Weekly nutrient summary
    today = date.today()
    start_of_week = today - timedelta(days=today.weekday())
    weekly_summary = {}

    for i in range(7):
        day = start_of_week + timedelta(days=i)
        tracked = TrackedMeal.objects.filter(user=request.user, date_logged=day)
        weekly_summary[day.strftime("%a")] = {
            'calories': sum(t.meal.calories for t in tracked),
            'protein': sum(t.meal.protein for t in tracked),
            'carbs': sum(t.meal.carbs for t in tracked),
            'fats': sum(t.meal.fats for t in tracked),
        }

    context = {
        'recently_viewed_meals': recently_viewed_meals,
        'favourite_meals': favourite_meals,
        'goal': goal,
        'calorie_target': calorie_target,
        'profile': profile,
        'daily_motivation': daily_motivation,
        'category_chart': json.dumps(category_chart),
        'weekly_summary': json.dumps(weekly_summary)  # ✅ for nutrient chart
    }

    return render(request, 'dashboard.html', context)


# Meal Filtering and Sorting View
def meals_view(request):
    form = MealFilterForm(request.GET or None)
    show_all = request.GET.get('all') == 'true'
    meals = Meal.objects.all()

    if form.is_valid():
        selected_categories = form.cleaned_data.get('category_choices')
        if selected_categories:
            meals = meals.filter(categories__in=selected_categories).distinct()

    sort_by = request.GET.get('sort_by', '')
    if sort_by == 'calories':
        meals = meals.order_by('calories')
    elif sort_by == 'protein':
        meals = meals.order_by('-protein')
    elif sort_by == 'fibre':
        meals = meals.order_by('-fibre')
    elif sort_by == 'low_fat':
        meals = meals.order_by('fats')
    elif sort_by == 'low_carbs':
        meals = meals.order_by('carbs')

    if not show_all:
        meals = meals[:6]  # Only show 6 meals initially

    return render(request, 'meals.html', {
        'form': form,
        'meals': meals,
        'show_all': show_all
    })

# Comments View
@login_required
def comments(request):
    show_all = request.GET.get('all') == 'true'

    if show_all:
        all_comments = Comment.objects.filter(parent__isnull=True).order_by('-created_at')
    else:
        all_comments = Comment.objects.filter(parent__isnull=True).order_by('-created_at')[:4]

    if request.method == 'POST':
        user_comment = request.POST.get('comment')
        parent_id = request.POST.get('parent_id')
        parent = Comment.objects.filter(id=parent_id).first() if parent_id else None

        if user_comment:
            Comment.objects.create(content=user_comment, user=request.user, parent=parent)
            return redirect('comments')

    return render(request, 'comment.html', {'comments': all_comments, 'show_all': show_all})

# Favourites Functionality
@login_required
def add_to_favourites(request, meal_id):
    meal = get_object_or_404(Meal, id=meal_id)
    FavouriteMeal.objects.get_or_create(user=request.user, meal=meal)  # ✅ Prevent duplicate entries
    return redirect('favourite')

@login_required
def favourites_list(request):
    favourite_meals = FavouriteMeal.objects.filter(user=request.user).order_by('-added_at')
    return render(request, "favourite.html", {"favourite_meals": favourite_meals})

@login_required
def remove_from_favourites(request, meal_id):
    meal = get_object_or_404(Meal, id=meal_id)
    FavouriteMeal.objects.filter(user=request.user, meal=meal).delete()
    return redirect('favourite')



@login_required
def profile_view(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    return render(request, 'profile-view.html', {
        'user_profile': profile,
    })


@login_required
def update_profile(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=request.user.profile)  # ✅ add request.FILES
        if form.is_valid():
            form.save()
            return redirect('profile-view')
    else:
        form = ProfileForm(instance=request.user.profile)
    return render(request, 'profile.html', {'form': form})  # ✅ keep this if your template is profile.html


@login_required
def get_weekly_nutrients(user):
    today = date.today()
    start_of_week = today - timedelta(days=today.weekday())
    end_of_week = start_of_week + timedelta(days=6)

    meals = TrackedMeal.objects.filter(user=user, date_logged__range=(start_of_week, end_of_week))
    daily_data = {}

    for i in range(7):
        day = start_of_week + timedelta(days=i)
        meals_for_day = meals.filter(date_logged=day)

        daily_data[day.strftime("%a")] = {
            'calories': meals_for_day.aggregate(Sum('meal__calories'))['meal__calories__sum'] or 0,
            'protein': meals_for_day.aggregate(Sum('meal__protein'))['meal__protein__sum'] or 0,
            'carbs': meals_for_day.aggregate(Sum('meal__carbs'))['meal__carbs__sum'] or 0,
            'fats': meals_for_day.aggregate(Sum('meal__fats'))['meal__fats__sum'] or 0,
        }

    return daily_data



@login_required
def track_meal(request, meal_id):
    meal = get_object_or_404(Meal, id=meal_id)
    today = date.today()

    already_tracked = TrackedMeal.objects.filter(
        user=request.user,
        meal=meal,
        date_logged=today
    ).exists()

    if already_tracked:
        messages.error(request, "You already tracked this meal today.")
    else:
        TrackedMeal.objects.create(
            user=request.user,
            meal=meal,
            date_logged=today
        )
        messages.success(request, "Meal successfully tracked for today!")

    return redirect('meal_detail', meal_id=meal.id)