from django.db import models
from django.contrib.auth.models import User  # Importing Django's built-in User model


# Category Model: Represents meal categories (e.g., Vegan, High Protein)
class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)  # Category name must be unique

    def __str__(self):
        return self.name  # String representation of the model


# Meal Model: Represents individual meals with nutritional information
class Meal(models.Model):
    name = models.CharField(max_length=255)  # Meal name
    description = models.TextField()  # Meal description
    calories = models.PositiveIntegerField(default=0)  # Number of calories in the meal
    protein = models.FloatField(default=0.0)  # Protein content in grams
    carbs = models.FloatField(default=0.0)  # Carbohydrate content in grams
    fats = models.FloatField(default=0.0)  # Fat content in grams
    fibre = models.FloatField(default=0.0)  # Fibre content in grams
    image = models.ImageField(upload_to='meal_images/', blank=True, null=True)  # Optional image for the meal
    categories = models.ManyToManyField(Category, blank=True)  # Many-to-Many relation with Category
    ingredients = models.TextField(default="", blank=True)  # Ingredients list as text
    instructions = models.TextField(default="", blank=True)  # Cooking instructions as text

    def __str__(self):
        return self.name  # String representation of the model




class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)  # ✅ ADD THIS LINE
    weight = models.IntegerField(default=70)
    height = models.IntegerField(default=170)
    age = models.IntegerField(null=False, default=25)
    gender = models.CharField(
        max_length=10,
        choices=[('Male', 'Male'), ('Female', 'Female')],
        default='Female'
    )
    activity_level = models.CharField(
        max_length=20,
        blank=True,
        default='Sedentary',
        choices=[
            ('Sedentary', 'Sedentary'),
            ('Moderate', 'Moderate'),
            ('Active', 'Active'),
        ]
    )
    goal = models.CharField(
        max_length=50,
        choices=[
            ('Lose Weight', 'Lose Weight'),
            ('Gain Muscle', 'Gain Muscle'),
            ('Maintain Weight', 'Maintain Weight'),
        ],
        default='Maintain Weight'
    )

    def __str__(self):
        return f"{self.user.username}'s Profile"




# Comment Model: Represents user comments and allows nested replies
class Comment(models.Model):
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE)
    meal = models.ForeignKey(Meal, null=True, blank=True, on_delete=models.CASCADE)  # 👈 NEW!
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='replies')

    def __str__(self):
        return self.content[:50] 


class MealComment(Comment):
    class Meta:
        proxy = True
        verbose_name = "Meal Comment"
        verbose_name_plural = "Meal Comments"
        

# FavouriteMeal Model: Allows users to favourite meals
class FavouriteMeal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # The user who favourited the meal
    meal = models.ForeignKey(Meal, on_delete=models.CASCADE)  # The meal being favourited
    added_at = models.DateTimeField(auto_now_add=True)  # Timestamp of when it was added to favourites

    def __str__(self):
        return f"{self.user.username} - {self.meal.name}"  # String representation of the model


# ✅ ViewedMeal Model (Updated)
class ViewedMeal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    meal = models.ForeignKey(Meal, on_delete=models.CASCADE)
    viewed_at = models.DateTimeField(auto_now_add=True)  # Saves timestamp of when meal was viewed

    class Meta:
        ordering = ['-viewed_at']  # Show the most recently viewed meals first
        unique_together = ('user', 'meal')  # ✅ Prevent duplicate entries

    def __str__(self):
        return f"{self.user.username} viewed {self.meal.name}"
    



class TrackedMeal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    meal = models.ForeignKey(Meal, on_delete=models.CASCADE)
    date_logged = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} logged {self.meal.name} on {self.date_logged}"