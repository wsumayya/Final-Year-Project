from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Profile  # Importing the Profile model
from .models import Category  # Importing the Category model


class RegisterForm(UserCreationForm):  # Form for user registration
    email = forms.EmailField()  # Adding email field to collect user email

    class Meta:
        model = User  # Setting the model to Django's built-in User model
        fields = ['username', 'email', 'password1', 'password2']  # Defining the fields to be displayed

class ProfileForm(forms.ModelForm):
    # Include first name and last name from the User model
    first_name = forms.CharField(max_length=30, required=False, label="First name")
    last_name = forms.CharField(max_length=30, required=False, label="Last name")

    class Meta:
        model = Profile
        fields = ['profile_picture', 'weight', 'height', 'age', 'gender', 'activity_level', 'goal']

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)  # accept user explicitly
        super(ProfileForm, self).__init__(*args, **kwargs)
        if user:
            self.fields['first_name'].initial = user.first_name
            self.fields['last_name'].initial = user.last_name

    def save(self, user=None, commit=True):
        profile = super(ProfileForm, self).save(commit=False)
        if user:
            user.first_name = self.cleaned_data['first_name']
            user.last_name = self.cleaned_data['last_name']
            if commit:
                user.save()
        if commit:
            profile.save()
        return profile


class MealFilterForm(forms.Form):  # Form for filtering meals based on categories
    category_choices = forms.ModelMultipleChoiceField(
        queryset=Category.objects.all(),  # Fetching all categories from the database
        required=False,  
        widget=forms.CheckboxSelectMultiple,  # Display categories as multiple checkboxes
        label="Filter by Categories"  # Label for this field in the template
    )

    sort_by = forms.CharField(
        required=False,  # Sorting is optional
        label="Sort by",  # Label for sorting
        widget=forms.HiddenInput()  # Hidden input field, as dropdown selection will be in the template
    )

    def __init__(self, *args, **kwargs):  # Custom initialization of the form
        super().__init__(*args, **kwargs)
        self.fields['category_choices'].queryset = Category.objects.all()  # Dynamically setting category choices